/*
$(function() {  
    manageGallery();
});

function manageGallery(){
    function mixitup() {
        $("#faq").mixItUp({
            animation: {
                duration: 400,
                effects: "fade translateZ(-360px) stagger(34ms)",
                easing: "ease",
                queueLimit: 3,
                animateChangeLayout: true,
                animateResizeTargets: true
            }
        });
    }

    mixitup();
}

*/