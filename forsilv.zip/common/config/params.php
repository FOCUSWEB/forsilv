<?php
return [
	'adminEmail' => 'admin@example.com',
	'supportEmail' => 'support@example.com',
	'user.passwordResetTokenExpire' => 3600,

	//  公司名称
	'company_name' => '重庆五岳商贸有限公司',
];
