<?php

namespace frontend\controllers;

class BaseController extends \yii\web\Controller
{
}
